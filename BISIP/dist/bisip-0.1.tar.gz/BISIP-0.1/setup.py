# -*- coding: utf-8 -*-
"""
Created on Fri Sep 29 16:18:50 2017

@author: Charles
"""

from setuptools import setup

setup(
    name='BISIP',      # This is the name of your PyPI-package.
    version='0.1',                          # Update the version number for new releases
    scripts=['BISIP']                  # The name of your scipt, and also the command you'll be using for calling it
)

