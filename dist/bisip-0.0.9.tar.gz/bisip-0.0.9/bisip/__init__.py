#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  3 09:08:33 2017

@author: Charles
"""

from bisip.models import mcmcinv